$ErrorActionPreference = 'Stop'
$codexDir = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
$destination = Join-Path $codexDir 'skills'
New-Item -ItemType Directory -Path $destination -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'skills') -Directory | ForEach-Object {
    $target = Join-Path $destination $_.Name
    if (Test-Path -LiteralPath $target) {
        Write-Output "Kept existing: $($_.Name)"
    } else {
        Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse
        Write-Output "Installed: $($_.Name)"
    }
}

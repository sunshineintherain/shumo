@echo off
chcp 65001 >nul
setlocal
set "PYTHONUTF8=1"
cd /d "%~dp0"
if not defined MCM_PYTHON if exist "%~dp0.venv\Scripts\python.exe" set "MCM_PYTHON=%~dp0.venv\Scripts\python.exe"
if not defined MCM_PYTHON goto use_py
"%MCM_PYTHON%" "%~dp0app\launch.py" %*
goto check
:use_py
py -3.12 "%~dp0app\launch.py" %*
:check
if errorlevel 1 (
  echo Startup failed. See README.md and app\server-error.log.
  pause
  exit /b 1
)
endlocal

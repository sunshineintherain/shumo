# 数模工作流与 Skills

版本 3.2.0-workflow-audit，适用于 Windows。

1. 解压并进入顶层文件夹，准备 Python 3.12。在此处打开终端，运行下面两条命令。
2. 双击「启动工作流.cmd」，添加赛题来源路径，再选择成果保存目录。
3. 在解压目录运行 `powershell -NoProfile -File .\install-skills.ps1`，将所需 Skills 加入 Codex。脚本保留已存在的同名技能。也可手动复制 skills 中需要的目录到用户的 .codex/skills。打开新 Codex 聊天后使用。已启用 PDF 或 Spreadsheets 插件时，可直接调用相应插件技能。
4. 在 Codex 打开成果目录并使用生成的提示词。阶段 06 的论文图使用英文标注，阶段 07 和 08 生成和审查英文论文。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

若 Python 3.12 未注册到 py 启动器，可用该版本 python.exe 的完整路径执行第一条命令。安装依赖需要联网。工作流本身使用 Python 标准库。部分技能的选用功能需要额外工具或插件，详见对应 SKILL.md。

包内含 8 阶段配置、9 个 Skills、依赖清单和测试。请从原项目另行提供赛题材料和已有成果。

## Skill 来源

- K-Dense-AI/scientific-agent-skills 提供 exploratory-data-analysis、sympy、pymoo 和 scientific-visualization。
- 本机已安装的 verification-before-completion、scientific-writing 和 peer-review。
- Codex 插件内置 pdf 和 spreadsheets。

"""Local-only workflow guide. No model calls or automated quality judgments."""
import copy
import json
import os
from pathlib import Path
import re
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import uuid
import shutil
import subprocess
import sys
DIRECTORY_CHOICES = {}

def choose_directory(purpose='save'):
    result = subprocess.run([sys.executable, str(ROOT / 'choose_directory.py'), purpose], capture_output=True, text=True, encoding='utf-8', timeout=600)
    if result.returncode:
        raise ValueError('系统目录选择窗口无法打开（需要本机桌面及Tk支持）：' + result.stderr[-500:])
    directory = json.loads(result.stdout)['directory']
    if not directory:
        return {'cancelled': True}
    token = uuid.uuid4().hex
    DIRECTORY_CHOICES[token] = Path(directory).resolve()
    return {'cancelled': False, 'token': token}

def materialize(p, parent):
    if not p.get('setupPending'):
        return p
    if not parent.is_dir():
        raise ValueError('所选目录不存在，请重新选择')
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', p['name']).strip(' .')[:80] or '赛题项目'
    if name.upper().split('.')[0] in ['CON','PRN','AUX','NUL'] + [f'{x}{n}' for x in ['COM','LPT'] for n in range(1,10)]:
        name = '赛题_' + name
    target = None
    try:
        for n in range(10000):
            candidate = parent / (name if n == 0 else f'{name} ({n})')
            try:
                candidate.mkdir()
                target = candidate.resolve()
                break
            except FileExistsError:
                continue
        if target is None:
            raise ValueError('同名目录过多，请修改项目名称')
        q = copy.deepcopy(p)
        for s in STAGES:
            (target / '成果' / f"{s['id']:02d}").mkdir(parents=True)
        (target / '交接').mkdir()
        q.update(workspace=str(target), workspaceInitialized=True, setupPending=False, drafts={})
        q['stages'][0]['status'] = '进行中'
        save(q)
        return q
    except Exception as e:
        # Remove only the directory exclusively created by this operation.
        if target is not None and target.parent == parent.resolve():
            try:
                shutil.rmtree(target)
            except OSError:
                pass
        raise ValueError(f'成果目录创建失败：{e}。题目路径仍保留，请重新选择位置或重试。') from e

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('MCM_DATA_DIR', ROOT / 'local-data'))
STAGES = json.loads((ROOT / 'config/stages.json').read_text(encoding='utf-8'))
TEMPLATES = json.loads((ROOT / 'config/prompts.json').read_text(encoding='utf-8'))
LOCK = threading.RLock()
STATUSES = ['未开始', '进行中', '待 Codex 复核', '修正中', '用户确认已复核通过', '需重新复核']
DEFAULT_SCOPE = '单小问试跑：请先选定一道真实历史赛题及一个小问；未选定时由Codex询问用户，不得混用题目，不视为完整赛题论文。'
JOURNAL_FIELDS = ['executionLog', 'reviewLog', 'missing', 'handoffIssues', 'promptChanges', 'skillCandidates']
APPROVED = '用户确认已复核通过'

def now():
    return datetime.now(timezone.utc).isoformat()

def save(p):
    DATA.mkdir(parents=True, exist_ok=True)
    target = DATA / (p['id'] + '.json')
    tmp = target.with_suffix('.tmp')
    tmp.write_text(json.dumps(p, ensure_ascii=False, indent=2), encoding='utf-8')
    if p.get('workspaceInitialized'):
        project_state = Path(p['workspace']) / '项目状态.json'
        project_tmp = project_state.with_suffix('.tmp')
        project_tmp.write_text(json.dumps(p, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(project_tmp, project_state)
    os.replace(tmp, target)

def load(pid):
    if not re.fullmatch(r'[a-f0-9]{32}', pid):
        raise ValueError('项目编号无效')
    return json.loads((DATA / (pid + '.json')).read_text(encoding='utf-8'))

def skill_status(s):
    path = s.get('skillPath')
    candidates = [ROOT.parent / path] if path else [Path.home() / '.codex/skills' / s['skill'] / 'SKILL.md']
    return '检测到本地文件，仍需在目标聊天核实可用' if any(p.is_file() for p in candidates) else '未检测到安装；需配置或按提示词直接执行'

def prompt_blocked(p, index):
    return index > 0 and (p.get('materialNotice') or
                          any(stage['status'] != APPROVED for stage in p['stages'][:index]))

def reopen_stage(p, index):
    p['current'] = index
    p['stages'][index].update(status='修正中', confirmedAt=None)
    for stage in p['stages'][index + 1:]:
        if stage['status'] != '未开始':
            stage.update(status='需重新复核', confirmedAt=None)
    if index == 0:
        p['materialNotice'] = False

def upgrade_prompts(p):
    if p['templates']['version'] == TEMPLATES['version']:
        return False
    p['templateHistory'].append(dict(at=now(), templates=p['templates'],
                                     drafts=copy.deepcopy(p['drafts'])))
    p['templates'] = copy.deepcopy(TEMPLATES)
    p['drafts'] = {}
    p['draftRevisions'] = {}
    p['promptRevision'] = p.get('promptRevision', 0) + 1
    return True

def prompt(p, index, kind):
    s = STAGES[index]
    state = p['stages'][index]
    materials = p['templates']['read_materials'].format(source_folder=p['sourceFolder'])
    workspace = p['workspace'] or '尚未选择成果保存目录'
    output_dir = str(Path(workspace) / '成果' / f'{index+1:02d}')
    handoff_file = str(Path(workspace) / '交接' / f'阶段{index+1:02d}.md')
    prior = '\n'.join(f"第{i+1}阶段 {STAGES[i]['name']}：{x['status']}；用户记录成果：{x['outputs'] or '未记录，不能认定已产生'}；约定查找目录（不是存在证明）：{Path(workspace) / '成果' / f'{i+1:02d}'}；交接文件（需实际核实）：{Path(workspace) / '交接' / f'阶段{i+1:02d}.md'}；备注/复核结论：{x['notes']}" for i, x in enumerate(p['stages'][:index])) or '无前序阶段。'
    journal = '\n'.join(f'{k}：{state.get(k) or "未记录，未执行不能视为完成"}' for k in JOURNAL_FIELDS)
    context = f"当前使用提示词流程，Skill不是必需依赖。可选Skill：{s['skill']}（{skill_status(s)}），仅实际可用且适用时调用，缺失时直接执行下面步骤，不阻止流程，不声称已安装或调用。\n赛题项目：{p['name']}\n试跑/执行范围：{p.get('scope', DEFAULT_SCOPE)}\n成果项目目录：{workspace}\n必读项目背景文件：{Path(workspace) / '项目状态.json'}（软件记录，不是质量证明）。\n本地环境：在Codex打开成果项目目录，按来源路径读取原件；软件只记录来源路径，没有读取或复制材料。\n云端环境：本地路径不可直接读取，必须上传原件、项目状态及前序成果；核实本聊天工具能力。\n必读原始材料：\n{materials}\n人工补充（非原件验证）：{p['manual']}\n前序成果记录（只列前序，不预填下游结果；路径约定不等于文件存在）：\n{prior}\n当前阶段成果记录：{state['outputs'] or '未记录；首次执行应产生，复核/修正时必须核实实际文件'}\n当前备注/复核结论：{state['notes']}\n阶段实测记录（用户记录，须核实）：\n{journal}\n读取规则：先核实原件、正式成果及交接文件是否实际存在，缺失输入不得当作已完成；交接总结仅是索引，必须打开其指向的真实文件。未开始或需重新复核的上游不能作为已通过证据。\n回退规则：发现上游错误，列出最早受影响阶段、证据文件和下游影响；先完成可独立工作，阻塞则停止推进。请用户回软件导航到该阶段，点击“返回本阶段修正并提醒下游”或“本阶段正式成果已变更”，修复后重新提交复核；不代替用户确认通过。"
    record_contract = f"本阶段成果保存目录：{output_dir}\n阶段文件交接：保存到 {handoff_file}，包含范围、已实际读取文件及版本、实际产物路径、执行/自检/独立复核情况、缺失输入输出、阻塞、交接失败点、需修改的提示词、适合以后固化进Skill的方法、下一步需读取的实际文件。没有做的填写未执行，不得提前填写下游数值或结论。复核/修正时更新并保留旧版本；只有无阻塞时才建议用户确认，试跑不称为整题完成。\n同时在 {output_dir} 保存 执行记录.md、复核记录.md、修正记录.md（按实际发生情况填写，不要求伪造未执行记录）。软件成果位置/记录字段为可选，不代替质量复核；回软件填实际执行、复核、缺失、交接失败、提示词改进和Skill候选方法。"
    values = dict(stage=s['name'], stage_id=str(index+1).zfill(2), goal=s['goal'], skill=s['skill'], skill_status=skill_status(s), context=context, record_contract=record_contract, output_dir=output_dir)
    for k in ['inputs', 'steps', 'outputs', 'checklist']:
        values[k] = '\n'.join('- ' + x for x in s[k])
    values['parallel_tasks'] = s['parallelTasks']
    values['paper_language'] = s.get('paperLanguage', '')
    if s.get('skillUsage'):
        values['context'] += '\nSkill 选择与运行条件：' + s['skillUsage']
        local_python = ROOT.parent / '.venv' / 'Scripts' / 'python.exe'
        if local_python.is_file():
            values['context'] += f'\n本地可检查的备用 Python 环境：{local_python}。优先沿用当前赛题已验证的项目环境。'
    templates = p['templates']
    values['execution'] = templates['execute'].format(**values)
    return templates[kind].format(**values)

def api(action, a):
    if action == 'choose-directory':
        return choose_directory('save')
    if action == 'list':
        return [dict(id=p['id'], name=p['name']) for p in [load(f.stem) for f in DATA.glob('*.json')]]
    if action == 'config':
        return [dict(s, skillStatus=skill_status(s), promptVersion=TEMPLATES['version']) for s in STAGES]
    if action in ['upload','folder-start','folder-status','folder-retry','folder-cancel','remove']:
        raise ValueError('材料读取已交给Codex Agent；请填写题目所在文件夹路径')
    if action == 'create':
        source = a.get('sourceFolder','').strip().strip('"')
        if not (re.match(r'^[A-Za-z]:[\\/]',source) or source.startswith('\\\\')) or any(x in source for x in ['\n','\r','\x00']):
            raise ValueError('请填写题目所在文件夹的完整路径，例如 E:\\数模真题；软件不读取该路径')
        p = dict(id=uuid.uuid4().hex, name=a['name'].strip() or '未命名赛题', workspace=a.get('workspace', ''), manual='', current=0, materials=[], history=[], templates=copy.deepcopy(TEMPLATES), templateHistory=[], drafts={}, stages=[dict(status='未开始', outputs='', notes='', confirmedAt=None) for _ in STAGES])
        p.update(sourceFolder=source,workspace='',setupPending=True,scope=DEFAULT_SCOPE)
        p['stages'][0]['status'] = '未开始'
        save(p)
        return p
    p = load(a['id'])
    original = copy.deepcopy(p)
    if 'index' in a and not 0 <= int(a['index']) < len(STAGES):
        raise ValueError('阶段编号超出范围')
    if action == 'get':
        return p
    if action == 'initialize':
        if not p.get('setupPending'):
            return p
        parent = DIRECTORY_CHOICES.get(a.get('token'))
        if parent is None:
            raise ValueError('目录选择已失效，请重新选择保存位置')
        return materialize(p, parent)
    if action == 'upgrade-prompts':
        if upgrade_prompts(p):
            save(p)
        return p
    if action == 'prompt':
        i = int(a['index'])
        if not STAGES[i]['enabled']:
            raise ValueError('该阶段模板尚未启用')
        blocked = prompt_blocked(p, i)
        if blocked and a.get('preview') is not True:
            raise ValueError('请先完成上游阶段复核确认；当前阶段仅可预览')
        text = prompt(p, i, a['kind'])
        if blocked:
            text = '【仅供预览】上游阶段尚未完成复核确认。请等待解锁后再执行。\n\n' + text
        return dict(text=text, blocked=bool(blocked),
                    revision=p.get('promptRevision', 0))
    if action == 'edit':
        for k in ['workspace', 'manual', 'scope']:
            if k in a:
                if k == 'workspace' and p.get('workspaceInitialized'):
                    continue
                p[k] = a[k]
        if 'index' in a:
            for k in ['outputs', 'notes'] + JOURNAL_FIELDS:
                if k in a:
                    p['stages'][int(a['index'])][k] = a[k]
    elif action == 'draft':
        key = a['key']
        revisions = p.setdefault('draftRevisions', {})
        if a.get('discard') is True:
            p['drafts'].pop(key, None)
            revisions.pop(key, None)
        else:
            p['drafts'][key] = a['text']
            revisions[key] = a.get('revision')
    elif action == 'templates':
        t = a['templates']
        if not isinstance(t.get('version'), str) or not t['version'].strip() or t['version'] == p['templates']['version']:
            raise ValueError('请填写不同的新模板版本号')
        for k in ['execute', 'review', 'fix', 'handoff', 'read_materials']:
            if not isinstance(t.get(k), str) or not t[k].strip():
                raise ValueError('四类提示词与Agent读取要求模板均不能为空')
        old = p['templates']
        p['templates'] = t
        for i in range(len(STAGES)):
            for k in ['execute', 'review', 'fix', 'handoff']:
                prompt(p, i, k)  # Validate all stages before saving.
        p['templateHistory'].append(dict(at=now(), templates=old))
        p['promptRevision'] = p.get('promptRevision', 0) + 1
    elif action == 'transition':
        i = int(a['index'])
        st = p['stages'][i]
        event = a['event']
        if prompt_blocked(p, i):
            raise ValueError('请先完成上游阶段的修正与复核确认，再操作本阶段状态')
        allowed = {'complete': ['进行中', '修正中'], 'fix': ['待 Codex 复核', '需重新复核'], 'pass': ['待 Codex 复核'], 'return': STATUSES, 'changed': STATUSES, 'recheck': ['需重新复核']}
        if not STAGES[i]['enabled'] or st['status'] not in allowed.get(event, []):
            raise ValueError('当前状态不支持此操作')
        before = st['status']
        if event == 'complete' or event == 'recheck':
            st['status'] = '待 Codex 复核'
        elif event == 'fix' or event == 'return':
            st['status'] = '修正中'
        elif event == 'pass':
            st['status'] = '用户确认已复核通过'
            st['confirmedAt'] = now()
            if i+1 < len(STAGES) and STAGES[i+1]['enabled']:
                p['current'] = i+1
                if p['stages'][i+1]['status'] == '未开始':
                    p['stages'][i+1]['status'] = '进行中'
        if event in ['return', 'changed']:
            reopen_stage(p, i)
        p['history'].append(dict(at=now(), stage=i+1, event=event, before=before, after=st['status'], notes=st['notes'], outputs=st['outputs'], scope=p.get('scope', DEFAULT_SCOPE), journal={k:st.get(k,'') for k in JOURNAL_FIELDS}, materials=copy.deepcopy(p['materials']), templateVersion=p['templates']['version']))
        p['promptRevision'] = p.get('promptRevision', 0) + 1
    else:
        raise ValueError('未知操作')
    if action in ['edit', 'remove', 'upload'] and original != p:
        p.setdefault('recordHistory', []).append(dict(at=now(), action=action, materials=original['materials'], manual=original['manual'], scope=original.get('scope',DEFAULT_SCOPE), workspace=original['workspace'], stages=original['stages']))
        p['promptRevision'] = p.get('promptRevision', 0) + 1
        scope_changed = original.get('scope', DEFAULT_SCOPE) != p.get('scope', DEFAULT_SCOPE)
        inputs_changed = original['manual'] != p['manual'] or original['materials'] != p['materials']
        if (scope_changed or inputs_changed) and p['stages'][0]['status'] in (APPROVED, '待 Codex 复核'):
            reopen_stage(p, 0)
    save(p)
    return p

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split('?')[0]
        files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/style.css': ('style.css', 'text/css')}
        if path not in files:
            self.send_error(404)
            return
        name, mime = files[path]
        raw = (ROOT / 'static' / name).read_bytes()
        self.send_response(200)
        self.send_header('Content-Type', mime + '; charset=utf-8')
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        shutdown_requested = False
        try:
            # Prevent another web origin from mutating local projects.
            origin = self.headers.get('Origin')
            if origin and origin != 'http://' + self.headers.get('Host', ''):
                raise ValueError('拒绝跨站请求')
            if self.headers.get('Host') not in ['127.0.0.1:8765', 'localhost:8765']:
                raise ValueError('主机无效')
            n = int(self.headers.get('Content-Length', '0'))
            if n > 43 * 1024 * 1024:
                raise ValueError('请求过大，单文件限制30MB')
            a = json.loads(self.rfile.read(n))
            with LOCK:
                if self.path == '/api/shutdown':
                    result = {'stopped': True}
                    shutdown_requested = True
                else:
                    result = api(self.path.removeprefix('/api/'), a)
            raw = json.dumps(result, ensure_ascii=False).encode()
            self.send_response(200)
        except Exception as e:
            raw = json.dumps({'error': str(e)}, ensure_ascii=False).encode()
            self.send_response(400)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.end_headers()
        self.wfile.write(raw)
        self.wfile.flush()
        if shutdown_requested:
            # shutdown() must run outside the serve_forever thread.
            threading.Thread(target=self.server.shutdown, daemon=True).start()

if __name__ == '__main__':
    DATA.mkdir(parents=True, exist_ok=True)
    print('数学建模工作流：http://127.0.0.1:8765', flush=True)
    server = ThreadingHTTPServer(('127.0.0.1', 8765), Handler)
    if '--open' in __import__('sys').argv:
        import webbrowser
        webbrowser.open('http://127.0.0.1:8765')
    try:
        server.serve_forever()
    finally:
        server.server_close()

import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('workflow',Path(__file__).parents[1]/'server.py')
s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)

class WorkflowTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(dir=Path(__file__).parent);self.old=s.DATA;s.DATA=Path(self.tmp.name)/'records'
  self.p=s.api('create',{'name':'路径引导测试','sourceFolder':'E:\\不存在的测试题目文件夹'})
 def tearDown(self):
  s.DATA=self.old;self.tmp.cleanup()
 def test_path_only_and_stage_loop(self):
  self.assertTrue(self.p['setupPending']);self.assertEqual(self.p['materials'],[])
  self.assertFalse(hasattr(s,'extract'))
  for action in ['upload','folder-start','folder-status','folder-retry']:
   with self.assertRaisesRegex(ValueError,'交给Codex Agent'):s.api(action,{})
  parent=Path(self.tmp.name)/'成果';parent.mkdir()
  with patch.object(Path,'iterdir',side_effect=AssertionError('不得扫描来源')):
   self.p=s.materialize(self.p,parent)
   for kind in ['execute','review','fix','handoff']:
    text=s.prompt(self.p,0,kind)
    self.assertIn(self.p['sourceFolder'],text);self.assertIn('软件未扫描',text);self.assertIn('安全展开',text);self.assertIn('失败原因',text)
  self.assertFalse((Path(self.p['workspace'])/'原始材料').exists())
  self.assertEqual(len(list((Path(self.p['workspace'])/'成果').iterdir())),8)
  for event in ['complete','fix','complete','pass']:
   self.p=s.api('transition',{'id':self.p['id'],'index':0,'event':event})
  self.assertEqual(self.p['current'],1)
  self.assertEqual(s.load(self.p['id']),self.p)
 def test_validation_and_templates(self):
  with self.assertRaises(ValueError):s.api('create',{'name':'x','sourceFolder':'relative/path'})
  with self.assertRaises(ValueError):s.api('create',{'name':'x'})
  parent=Path(self.tmp.name)/'save';parent.mkdir();self.p=s.materialize(self.p,parent)
  with self.assertRaises(ValueError):s.api('transition',{'id':self.p['id'],'index':1,'event':'return'})
  t=copy.deepcopy(self.p['templates']);t['version']='test-new';t['execute']+='\n额外自检'
  self.p=s.api('templates',{'id':self.p['id'],'templates':t});self.assertIn('额外自检',s.prompt(self.p,0,'execute'))
 def test_eight_stage_software_contract_not_real_exam_review(self):
  parent=Path(self.tmp.name)/'software-only';parent.mkdir();self.p=s.materialize(self.p,parent)
  self.assertTrue(all(x['enabled'] and len(x['steps'])>=4 and len(x['checklist'])>=4 for x in s.STAGES))
  # State fixtures test software transitions only; they are not actual Codex approvals.
  with patch.object(s,'skill_status',return_value='未检测到安装'):
   for i in range(8):
    self.assertEqual(self.p['current'],i)
    for kind in ['execute','review','fix','handoff']:
     text=s.api('prompt',{'id':self.p['id'],'index':i,'kind':kind})['text']
     for expected in ['Skill不是必需依赖','项目状态.json',f'阶段{i+1:02d}.md','回退规则','未验证','单小问']:
      self.assertIn(expected,text)
    self.p=s.api('edit',dict(id=self.p['id'],index=i,outputs=f'仅测试夹具/阶段{i+1}',notes='软件状态回归，非实际赛题成果',**{k:'隔离测试记录' for k in s.JOURNAL_FIELDS}))
    if i<7:
     # Later-stage stored content must not be injected into current prompts.
     q=copy.deepcopy(self.p);q['stages'][i+1]['outputs']='FUTURE_RESULT_MUST_NOT_APPEAR'
     self.assertNotIn('FUTURE_RESULT_MUST_NOT_APPEAR',s.prompt(q,i,'execute'))
    self.p=s.api('transition',dict(id=self.p['id'],index=i,event='complete'))
    if i==4:
     self.p=s.api('transition',dict(id=self.p['id'],index=i,event='fix'))
     with self.assertRaises(ValueError):s.api('transition',dict(id=self.p['id'],index=i,event='pass'))
     self.p=s.api('transition',dict(id=self.p['id'],index=i,event='complete'))
    self.p=s.api('transition',dict(id=self.p['id'],index=i,event='pass'))
    self.assertEqual(s.load(self.p['id']),self.p)
  self.assertEqual(len(self.p['history'][-1]['journal']),6)
  previous_history=copy.deepcopy(self.p['history'])
  self.p=s.api('transition',dict(id=self.p['id'],index=2,event='return'))
  self.assertTrue(all(x['status']=='需重新复核' for x in self.p['stages'][3:]))
  self.assertEqual(self.p['history'][:-1],previous_history)
  with self.assertRaises(ValueError):s.api('transition',dict(id=self.p['id'],index=3,event='pass'))
  for i in range(2,8):
   event='complete' if i==2 else 'recheck'
   self.p=s.api('transition',dict(id=self.p['id'],index=i,event=event))
   self.p=s.api('transition',dict(id=self.p['id'],index=i,event='pass'))
  self.assertEqual(s.load(self.p['id']),self.p)
 def test_upgrade_keeps_progress_and_archives_drafts(self):
  parent=Path(self.tmp.name)/'save';parent.mkdir();self.p=s.materialize(self.p,parent)
  self.p['templates']['version']='2.0.0-agent-reading';self.p['drafts']={'0:execute':'用户旧草稿'};s.save(self.p)
  original=copy.deepcopy(self.p)
  self.p=s.api('upgrade-prompts',dict(id=self.p['id']))
  for k in ['stages','history','workspace','sourceFolder','current']:
   self.assertEqual(self.p[k],original[k])
  self.assertEqual(self.p['templateHistory'][-1]['drafts'],original['drafts'])
  self.assertEqual(self.p['drafts'],{})
  self.assertEqual(s.api('upgrade-prompts',dict(id=self.p['id'])),self.p)
  self.p=s.api('edit',dict(id=self.p['id'],scope='仅测试新的范围'))
  self.assertIn('仅测试新的范围',s.prompt(self.p,0,'execute'))

 def test_scope_change_invalidates_confirmations_and_blocks_handoff(self):
  parent=Path(self.tmp.name)/'scope-change';parent.mkdir()
  self.p=s.materialize(self.p,parent)
  project_id=self.p['id']
  for index in range(7):
   for event in ['complete','pass']:
    self.p=s.api('transition',dict(id=project_id,index=index,event=event))
  revision=self.p['promptRevision']
  history=copy.deepcopy(self.p['history'])
  self.p=s.api('edit',dict(id=project_id,scope='另一小问'))
  self.assertEqual(self.p['current'],0)
  self.assertEqual(self.p['stages'][0]['status'],'修正中')
  self.assertTrue(all(x['status']=='需重新复核' for x in self.p['stages'][1:]))
  self.assertTrue(all(x['confirmedAt'] is None for x in self.p['stages']))
  self.assertEqual(self.p['history'],history)
  self.assertGreater(self.p['promptRevision'],revision)
  with self.assertRaisesRegex(ValueError,'仅可预览'):
   s.api('prompt',dict(id=project_id,index=7,kind='handoff'))
  with self.assertRaises(ValueError):
   s.api('transition',dict(id=project_id,index=7,event='recheck'))
  preview=s.api('prompt',dict(id=project_id,index=7,kind='handoff',preview=True))
  self.assertTrue(preview['blocked'])
  self.assertIn('另一小问',preview['text'])

 def test_draft_keeps_base_revision_until_discarded(self):
  project_id=self.p['id']
  key='0:execute'
  initial=s.api('prompt',dict(id=project_id,index=0,kind='execute'))
  updated=s.api('draft',dict(id=project_id,key=key,text='手改草稿',revision=initial['revision']))
  self.assertEqual(updated['draftRevisions'][key],initial['revision'])
  s.api('edit',dict(id=project_id,scope='新范围'))
  current=s.api('prompt',dict(id=project_id,index=0,kind='execute'))
  self.assertGreater(current['revision'],initial['revision'])
  self.assertEqual(s.load(project_id)['drafts'][key],'手改草稿')
  discarded=s.api('draft',dict(id=project_id,key=key,discard=True))
  self.assertNotIn(key,discarded['drafts'])
  self.assertNotIn(key,discarded['draftRevisions'])

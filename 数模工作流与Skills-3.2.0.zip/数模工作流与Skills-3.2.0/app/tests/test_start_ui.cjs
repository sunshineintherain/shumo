// Isolated DOM/network fixtures exercise the real app.js event handlers.
// These are software regression fixtures, not mathematical modelling results.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
class Element{
 constructor(){this.value='';this.textContent='';this.hidden=false;this.disabled=false;this.children=[];this.attrs={};this.style={};}
 addEventListener(){} setAttribute(k,v){this.attrs[k]=v;} removeAttribute(k){delete this.attrs[k];}
 replaceChildren(...v){this.children=v;} append(...v){this.children.push(...v);} focus(){this.focused=true;}
 scrollIntoView(){this.scrolled=true;} reset(){} select(){}
}
async function setup(storage=new Map()){
 const elements=new Map([...fs.readFileSync(path.join(root,'static/index.html'),'utf8').matchAll(/id="([^"]+)"/g)].map(x=>[x[1],new Element()]));
 const stages=JSON.parse(fs.readFileSync(path.join(root,'config/stages.json'),'utf8'));
 const fixture={id:'test-existing',name:'隔离软件回归夹具',workspace:'fixture-only',current:1,materials:[],manual:'',templates:{version:'1'},templateHistory:[],drafts:{'1:review':'既有复核草稿'},history:[],stages:stages.map((_,i)=>({status:i===0?'用户确认已复核通过':i===1?'待 Codex 复核':'未开始',outputs:'',notes:''}))};
 fixture.scope='初始范围';fixture.promptRevision=0;fixture.draftRevisions={'1:review':0};
 const before=JSON.stringify(fixture),calls=[];let hold,fail=false,failDraft=false;
 const copied=[];
 const context=vm.createContext({console,AbortSignal,setTimeout,clearTimeout,Blob,URL,
  document:{getElementById:id=>elements.get(id),createElement:()=>new Element(),querySelector:()=>new Element()},
  Option:function(text,value){this.text=text;this.value=value;},
  localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
  window:{addEventListener(){},scrollTo(){}},navigator:{clipboard:{writeText:async text=>copied.push(text)}},confirm:()=>true,
  fetch:async(url,options)=>{const action=url.split('/').pop();calls.push(action);if(action==='get'&&hold)await hold;if(action==='draft'&&failDraft)throw Error('connection lost');if(action==='get'&&fail)return {ok:false,status:400,json:async()=>({error:'测试服务错误'})};
   const body=JSON.parse(options.body);
   if(action==='edit'&&body.scope!==fixture.scope){fixture.scope=body.scope;fixture.promptRevision++;}
   if(action==='draft'){
    if(body.discard){delete fixture.drafts[body.key];delete fixture.draftRevisions[body.key];}
    else{fixture.drafts[body.key]=body.text;fixture.draftRevisions[body.key]=body.revision;}
   }
   const result=action==='config'?stages:action==='list'?[{id:fixture.id,name:fixture.name}]:action==='prompt'?{text:'夹具提示词 '+fixture.scope, revision:fixture.promptRevision, blocked:body.index>1}:structuredClone(fixture);
   return {ok:true,json:async()=>result};}
 });
 elements.get('kind').value='execute';vm.runInContext(fs.readFileSync(path.join(root,'static/app.js'),'utf8'),context);
 await vm.runInContext('Promise.all([...operations])',context);
 return {elements,fixture,before,calls,storage,context,copied,setHold:v=>hold=v,setFail:v=>fail=v,setFailDraft:v=>failDraft=v};
}
(async()=>{
 const t=await setup(),start=t.elements.get('startWorkflow');
 await start.onclick();assert.match(t.elements.get('startFeedback').textContent,/尚未选择项目/);assert.equal(t.calls.filter(x=>x==='get').length,0);
 t.elements.get('projects').value=t.fixture.id;
 let release;t.setHold(new Promise(r=>release=r));
 const first=start.onclick(),second=start.onclick();assert.equal(start.disabled,true);assert.equal(start.textContent,'正在进入…');release();await Promise.all([first,second]);t.setHold(null);
 assert.equal(t.calls.filter(x=>x==='get').length,1);assert.equal(t.calls.includes('create'),false);
 assert.equal(t.elements.get('stageTitle').textContent,'2. 数据理解与预处理');assert.equal(t.elements.get('status').textContent,'待 Codex 复核');assert.equal(t.elements.get('prompt').value,'既有复核草稿');assert.equal(JSON.stringify(t.fixture),t.before);
 await t.elements.get('nextHandoff').onclick();assert.match(t.elements.get('handoffFeedback').textContent,/请先在Codex完成.*复核/);assert.equal(t.elements.get('stageTitle').textContent,'2. 数据理解与预处理');assert.equal(t.calls.includes('transition'),false);
 t.setFail(true);await start.onclick();assert.match(t.elements.get('startFeedback').textContent,/测试服务错误.*重试/);assert.equal(start.disabled,false);
 t.setFail(false);await start.onclick();assert.match(t.elements.get('startFeedback').textContent,/已进入/);
 t.elements.get('prompt').oninput();
 t.setFailDraft(true);await start.onclick();assert.match(t.elements.get('startFeedback').textContent,/无法连接本地服务.*重试/);assert.equal(start.disabled,false);
 t.setFailDraft(false);await start.onclick();assert.match(t.elements.get('startFeedback').textContent,/已进入/);
 const restored=await setup(t.storage);assert.equal(restored.elements.get('status').textContent,'待 Codex 复核');assert.equal(restored.elements.get('prompt').value,'既有复核草稿');
 t.elements.get('scope').value='修订范围';
 await t.elements.get('saveRecords').onclick();
 assert.equal(t.fixture.drafts['1:review'],'既有复核草稿');
 assert.equal(t.elements.get('copy').disabled,true);
 assert.match(t.elements.get('promptNotice').textContent,/旧草稿/);
 await t.elements.get('generate').onclick();
 assert.equal(Object.hasOwn(t.fixture.drafts,'1:review'),false);
 t.elements.get('scope').value='最新范围';
 await t.elements.get('copy').onclick();
 assert.equal(t.copied.at(-1),'夹具提示词 最新范围');
 assert.equal(Object.hasOwn(t.fixture.drafts,'1:review'),false);
 await t.elements.get('nav').children[7].onclick();
 assert.equal(t.elements.get('copy').disabled,true);
 assert.equal(t.elements.get('export').disabled,true);
 assert.match(t.elements.get('promptNotice').textContent,/仅供预览/);
 console.log('PASS: missing project, correct stage, draft preservation, duplicate clicks, failure/retry, reload restore');
})().catch(e=>{console.error(e);process.exitCode=1;});

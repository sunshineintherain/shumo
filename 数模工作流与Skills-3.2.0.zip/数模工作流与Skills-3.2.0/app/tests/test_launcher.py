from pathlib import Path
import unittest

class LauncherFormatTest(unittest.TestCase):
    def test_windows_entry_remains_parseable(self):
        # Regression for the real cmd parser failure: 'CM_PYTHON not recognized'.
        raw = (Path(__file__).parents[2] / '启动工作流.cmd').read_bytes()
        raw.decode('ascii')
        self.assertNotIn(b'\n', raw.replace(b'\r\n', b''), 'Windows launcher must keep CRLF line endings')
        self.assertIn(b'"%~dp0app\\launch.py" %*', raw)

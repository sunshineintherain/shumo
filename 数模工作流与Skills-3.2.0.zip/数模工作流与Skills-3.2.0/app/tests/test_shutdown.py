"""Verify real HTTP shutdown, including the existing cross-origin boundary."""
import http.client
import importlib.util
from pathlib import Path
import threading
import unittest

spec = importlib.util.spec_from_file_location('shutdown_server', Path(__file__).parents[1] / 'server.py')
server_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server_module)

class ShutdownTest(unittest.TestCase):
    def test_shutdown_rejects_other_origin_and_stops_listener(self):
        class QuietHandler(server_module.Handler):
            def log_message(self, *args):
                pass
        server = server_module.ThreadingHTTPServer(('127.0.0.1', 0), QuietHandler)
        thread = threading.Thread(target=server.serve_forever)
        thread.start()
        try:
            def request(origin):
                connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=2)
                connection.request('POST', '/api/shutdown', '{}', {'Host':'127.0.0.1:8765', 'Origin':origin, 'Content-Type':'application/json'})
                response = connection.getresponse()
                result = response.status, response.read()
                connection.close()
                return result
            self.assertEqual(request('http://unrelated.example')[0], 400)
            self.assertTrue(thread.is_alive())
            status, body = request('http://127.0.0.1:8765')
            self.assertEqual(status, 200)
            self.assertIn(b'"stopped": true', body)
            thread.join(timeout=2)
            self.assertFalse(thread.is_alive())
        finally:
            if thread.is_alive():
                server.shutdown()
                thread.join(timeout=2)
            server.server_close()

if __name__ == '__main__':
    unittest.main()

const $=id=>document.getElementById(id);
let project=null, stages=[], selected=0, draftTimer, draftDirty=false, draftRevision, pendingDraft=Promise.resolve();
let exited=false, exiting=false;
let starting=false, creating=false;
const journalFields=['executionLog','reviewLog','missing','handoffIssues','promptChanges','skillCandidates'];
const defaultScope='单小问试跑：请先选定一道真实历史赛题及一个小问；未选定时由Codex询问用户，不得混用题目，不视为完整赛题论文。';
function extraRecords(){return {scope:$('scope').value,...Object.fromEntries(journalFields.map(k=>[k,$(k).value]))};}

const operations=new Set();
async function api(action,data={}){let r;try{r=await fetch('/api/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),signal:['choose-directory','initialize','upload'].includes(action)?undefined:AbortSignal.timeout(15000)});}catch(e){throw Error(e.name==='TimeoutError'?'本地服务15秒内未响应，请重试；仍失败时重新运行启动工作流.cmd':'无法连接本地服务，请先运行启动工作流.cmd，再重试');}const x=await r.json();if(!r.ok)throw Error(x.error||`服务返回HTTP ${r.status}`);return x;}
function notify(s){$('message').textContent=s;$('message').style.display='block';}
function safe(fn){return (...args)=>{const task=(async()=>{try{await fn(...args)}catch(e){notify('操作未完成：'+e.message)}})();operations.add(task);task.finally(()=>operations.delete(task));return task;}}
async function list(){const all=await api('list');$('projects').replaceChildren(new Option('选择已保存项目',''),...all.map(p=>new Option(p.name,p.id)));if(project)$('projects').value=project.id;}
function key(){return selected+':'+$('kind').value;}
async function flushDraft(){
 clearTimeout(draftTimer);
 await pendingDraft.catch(()=>{});
 if(!project||!draftDirty||!stages[selected].enabled)return;
 const text=$('prompt').value,k=key();
 pendingDraft=api('draft',{id:project.id,key:k,text,revision:draftRevision});
 const updated=await pendingDraft;
 project.drafts=updated.drafts;project.draftRevisions=updated.draftRevisions;
 if($('prompt').value===text&&key()===k){draftDirty=false;$('saveState').textContent='草稿已保存到本机';}
}
async function records(){
 if(!project||project.setupPending)return;
 await flushDraft();
 const current=project.current, firstStatus=project.stages[0].status;
 project=await api('edit',{id:project.id,workspace:$('projectPath').value,manual:$('manual').value,index:selected,outputs:$('outputs').value,notes:$('notes').value,...extraRecords()});
 if(project.current===0&&(current!==0||firstStatus!==project.stages[0].status)){
  selected=0;$('kind').value=preferredKind();await render();
  notify('范围或输入已更新，请从第 01 阶段重新复核。');
  return false;
 }
}
function count(){const n=Array.from($('prompt').value).length;$('count').textContent=`${n.toLocaleString()} 字符 · 未截断`+(n>18000?' · 内容较长，建议让 Codex 读取本地原件或上传附件；请按实际上下文容量拆分。':'');$('count').className=n>18000?'warning':'muted';}
async function showPrompt(preview=true){
 const k=key(),kind=$('kind').value;
 const generated=await api('prompt',{id:project.id,index:selected,kind,preview});
 const hasDraft=Object.hasOwn(project.drafts,k);
 draftRevision=hasDraft?project.draftRevisions?.[k]:generated.revision;
 const stale=hasDraft&&draftRevision!==generated.revision;
 $('prompt').value=hasDraft&&!generated.blocked?project.drafts[k]:generated.text;
 $('prompt').readOnly=generated.blocked;
 $('copy').disabled=$('export').disabled=Boolean(stale||generated.blocked);
 $('promptNotice').textContent=generated.blocked?'上游复核尚未通过。当前提示词仅供预览。':stale?'已保留旧草稿。请备份需要的编辑，再按最新记录重新生成。':'';
 count();
 return !stale;
}
async function preparePrompt(){
 if(await records()===false)return false;
 if(!await showPrompt(false)){notify('旧草稿仍在，请按最新记录重新生成后再复制或导出。');return false;}
 return true;
}
function textEl(tag,text){const el=document.createElement(tag);el.textContent=text;return el;}
function preferredKind(){const status=project.stages[selected].status;return ['待 Codex 复核','需重新复核'].includes(status)?'review':status==='修正中'?'fix':'execute';}
async function render(){
 if(project.setupPending){
  localStorage.setItem('lastMcmProject',project.id);$('work').hidden=true;$('exitWorkflow').hidden=false;$('stopSoftware').hidden=true;$('createPanel').open=true;$('name').value=project.name;$('projects').value=project.id;
  $('sourcePath').value=project.sourceFolder;$('startFeedback').textContent='题目路径已记录：'+project.sourceFolder+'。软件未读取内容，启动后复制提示词交给Agent读取。';return;
 }
const s=stages[selected],st=project.stages[selected];$('work').hidden=false;$('exitWorkflow').hidden=false;$('stopSoftware').hidden=true;$('createPanel').open=false;localStorage.setItem('lastMcmProject',project.id);previousKind=$('kind').value;$('projects').value=project.id;$('stageTitle').textContent=`${selected+1}. ${s.name}`;$('status').textContent=st.status;$('goal').textContent=s.goal;$('nav').replaceChildren();
 stages.forEach((x,i)=>{const b=textEl('button',`${i+1}. ${x.name}`);b.append(textEl('small',project.stages[i].status+(x.enabled?'':' · 模板待完善')));b.className=i===selected?'active':'';b.onclick=safe(async()=>{await records();selected=i;$('kind').value=preferredKind();await render()});$('nav').append(b)});
 const next={'进行中':'下一件事：复制执行提示词，在 Codex 完成本阶段。','未开始':'前序阶段尚未确认通过；可先查看说明。','修正中':'下一件事：复制修正提示词，继续相关 Codex 聊天；完成修正后再次提交复核。','待 Codex 复核':'下一件事：复制复核提示词，建议新建独立聊天核对原件和实际成果。','用户确认已复核通过':'此阶段已记录用户确认。可查看下一阶段；正式成果变更后请标记并重新复核。','需重新复核':'上游成果已变更：请重新核对本阶段，不能沿用旧确认。'};
 $('next').textContent=(project.materialNotice?'材料或补充文字已变更：请返回受影响的最早阶段，点击正式成果变更按钮提醒下游；不确定时从第一阶段重新复核。 ':'')+(s.enabled?next[st.status]:'本阶段仅有流程配置，模板尚未完善，本轮暂不启用操作。');
 $('instructions').replaceChildren();const guide=document.createElement('details');guide.append(textEl('summary','查看阶段操作、材料要求与验收清单'));for(const [title,items]of [['必需输入',s.inputs],['预期成果',s.outputs],['操作说明',s.steps],['复核清单',s.checklist]]){guide.append(textEl('p',title+'：'+items.join('；')))}guide.append(textEl('p','本地：在Codex打开下方成果保存目录，按来源路径读取原件；新聊天先读项目状态.json与交接文件，再读其指向的实际成果。云端：上传原件、项目状态和正式成果，本地路径不可用。'));$('instructions').append(textEl('p',`提示词流程 · 可选 Skill：${s.skill} · ${s.skillStatus}。缺失时直接执行提示词，不影响启动或阶段推进；配置保留供以后接入。`),guide);
 $('projectPath').value=project.workspace;$('manual').value=project.manual;$('outputs').value=st.outputs;$('notes').value=st.notes;$('templates').value=JSON.stringify(project.templates,null,2);$('templateVersion').textContent=` 当前 ${project.templates.version} · 历史版本 ${project.templateHistory.length}`;
 $('history').textContent=project.history.map(h=>`${new Date(h.at).toLocaleString('zh-CN')} 阶段${h.stage} ${h.before} → ${h.after} (${h.event}) 成果：${h.outputs||'未记录'} ${h.notes}`).join('\n')||'尚无确认记录';
 $('history').append(textEl('span','\n记录修改历史（含旧成果位置和材料关联）：\n'+JSON.stringify(project.recordHistory||[],null,2)));
 $('sourceRecord').value=project.sourceFolder;
 $('scope').value=project.scope||defaultScope;journalFields.forEach(k=>$(k).value=st[k]||'');
 $('upgradePrompts').hidden=project.templates.version===stages[0].promptVersion;
 $('nextHandoff').hidden=selected===stages.length-1;$('handoffFeedback').textContent='';
 $('promptCard').hidden=!s.enabled;$('changed').disabled=!s.enabled;$('actions').replaceChildren();
 if(s.enabled){const copyButton=textEl('button','复制当前提示词');copyButton.className='primary';copyButton.onclick=()=>$('copy').disabled?undefined:$('copy').onclick();$('actions').append(copyButton)}
 function action(label,event,primary=false){const b=textEl('button',label);if(primary)b.className='primary';b.onclick=safe(async()=>{if(await records()===false)return;const hasNext=Boolean(stages[selected+1]?.enabled);project=await api('transition',{id:project.id,index:selected,event});selected=project.current;if(event==='complete'||event==='recheck')$('kind').value='review';else if(event==='fix'||event==='return')$('kind').value='fix';else if(event==='pass')$('kind').value=hasNext?'handoff':'review';await render();notify(event==='pass'?(hasNext?'已记录你的复核确认；下一阶段启动词已准备。':'已记录最终阶段复核确认。确认仅针对当前范围；单小问试跑不代表整道赛题完成。'):'状态已保存。')});$('actions').append(b)}
 if(s.enabled){const blocked=selected>0&&project.materialNotice||project.stages.slice(0,selected).some(x=>x.status!=='用户确认已复核通过');if(blocked){$('actions').append(textEl('p','请先完成上游阶段复核确认；当前可预览和整理记录。'))}else{if(['进行中','修正中'].includes(st.status))action('本阶段任务已完成','complete',true);if(st.status==='待 Codex 复核'){action('发现问题，继续修正','fix');action(selected===stages.length-1?'已在 Codex 复核通过，确认当前范围交付':'已在 Codex 复核通过，进入下一阶段','pass',true)}if(st.status==='需重新复核'){action('开始重新复核','recheck',true);action('发现问题，继续修正','fix')}if(st.status==='用户确认已复核通过')action('返回本阶段修正并提醒下游','return');}await showPrompt();}
}
async function startWorkflow(){
 if(starting||creating||exiting||exited)return;
 const id=$('projects').value;
 if(!id){$('startFeedback').textContent='尚未选择项目。请从“恢复项目”选择一个项目，或在下方填写名称并创建项目。材料内容由Agent读取。';$('createPanel').open=true;$('name').focus();return;}
 starting=true;$('startWorkflow').disabled=true;$('projects').disabled=true;$('createProject').disabled=true;
 $('startWorkflow').textContent='正在进入…';$('startWorkflow').setAttribute('aria-busy','true');$('startFeedback').textContent='正在读取已保存的项目进度与阶段提示词…';
 try{
  if(project)await records();
  let restored=await api('get',{id});
  if(restored.setupPending){
   project=restored;await render();
   $('startFeedback').textContent='请选择阶段成果保存位置（题目原件将由Agent读取，不复制）。';
   const choice=await api('choose-directory');
   if(choice.cancelled){$('startFeedback').textContent='已取消保存位置选择，题目路径已保留，可再次启动。';return;}
   $('startFeedback').textContent='正在创建阶段成果目录并保存项目状态…';
   restored=await api('initialize',{id,token:choice.token});
  }
  if(!stages.length)stages=await api('config');
  if(!Number.isInteger(restored.current)||!stages[restored.current])throw Error('项目阶段记录无效，请保留项目文件并联系维护，未重置进度');
  project=restored;selected=project.current;$('kind').value=preferredKind();await render();
  $('startFeedback').textContent=`已进入“${project.name}”的第${selected+1}阶段：${stages[selected].name}。请复制提示词，由Codex Agent读取题目来源文件夹。`;
  $('stageTitle').scrollIntoView({block:'start'});
  notify('工作流已就绪。实际项目位置：'+(project.workspace||'旧项目未记录位置'));
 }catch(e){$('startFeedback').textContent='启动失败：'+e.message+'。请处理后再次点击“启动工作流”重试。';notify($('startFeedback').textContent);}
 finally{starting=false;$('startWorkflow').disabled=false;$('projects').disabled=false;$('createProject').disabled=false;$('startWorkflow').textContent='启动工作流';$('startWorkflow').removeAttribute('aria-busy');}
}
$('create').onsubmit=safe(async e=>{e.preventDefault();if(creating||starting)return;const name=$('name').value.trim();if(!name){$('startFeedback').textContent='请先填写项目名称。';return;}creating=true;$('createProject').disabled=true;try{if(project)await records();project=await api('create',{name,sourceFolder:$('sourcePath').value});selected=0;await list();await render();}finally{creating=false;$('createProject').disabled=false;}});
$('projects').onchange=()=>{$('startFeedback').textContent=$('projects').value?'已选择项目。点击“启动工作流”继续保存的阶段。':'请选择已有项目或创建新项目。';};
$('startWorkflow').onclick=safe(startWorkflow);
$('refresh').onclick=safe(list);
$('nextHandoff').onclick=safe(async()=>{if(await records()===false)return;if(selected>=stages.length-1)return;if(project.materialNotice||project.stages.slice(0,selected+1).some(x=>x.status!=='用户确认已复核通过')){$('handoffFeedback').textContent='请先在Codex完成本阶段复核及修正，再回软件确认通过。尚未产生的结果不会预填到下一阶段。';return;}selected++;$('kind').value='handoff';await render();notify('已显示下一阶段的新聊天启动词，请重新读取项目文件；软件未代替Codex执行。');});
$('upgradePrompts').onclick=safe(async()=>{if(!confirm('应用新版八阶段提示词？旧模板及所有草稿将归档至模板历史，阶段进度和成果记录保留。'))return;await records();project=await api('upgrade-prompts',{id:project.id});await render();notify('新版提示词已应用。旧模板与草稿已归档，进度未重置。');});
$('saveRecords').onclick=safe(async()=>{if(await records()===false)return;await showPrompt();notify('记录已保存。')});
let previousKind='execute';$('kind').addEventListener('focus',()=>{previousKind=$('kind').value});$('kind').onchange=safe(async()=>{const target=$('kind').value;$('kind').value=previousKind;await flushDraft();$('kind').value=target;previousKind=target;await showPrompt()});
$('prompt').oninput=()=>{draftDirty=true;count();$('saveState').textContent='正在保存草稿…请等待保存完成后关闭';clearTimeout(draftTimer);draftTimer=setTimeout(safe(flushDraft),400)};
$('generate').onclick=safe(async()=>{
 if(await records()===false)return;
 const k=key();
 if(Object.hasOwn(project.drafts,k)){
  if(!confirm('按最新记录重新生成将替换此类型的草稿。继续？'))return;
  project=await api('draft',{id:project.id,key:k,discard:true});
 }
 await showPrompt();notify('已按最新材料和记录生成。');
});
$('copy').onclick=safe(async()=>{if(!await preparePrompt())return;try{await navigator.clipboard.writeText($('prompt').value);notify('已复制完整提示词。')}catch(e){$('prompt').select();notify('浏览器未允许剪贴板，请按 Ctrl+C 复制已选中的全文。')}});
$('export').onclick=safe(async()=>{if(!await preparePrompt())return;const a=document.createElement('a'),url=URL.createObjectURL(new Blob([$ ('prompt').value],{type:'text/plain;charset=utf-8'}));a.href=url;a.download=`阶段${selected+1}-${$('kind').value}.txt`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('已导出完整提示词 TXT。')});
$('changed').onclick=safe(async()=>{if(!confirm('将当前阶段置为修正中，并将全部已开始的下游阶段标记为需重新复核。保留原确认历史。继续？'))return;if(await records()===false)return;project=await api('transition',{id:project.id,index:selected,event:'changed'});$('kind').value='fix';await render();notify('已标记成果变更与下游重新复核提醒。')});
$('saveTemplates').onclick=safe(async()=>{const t=JSON.parse($('templates').value);if(t.version===project.templates.version)throw Error('请更新 version 版本号');await records();project=await api('templates',{id:project.id,templates:t});await render();notify('模板新版本已保存；既有草稿保留，重新生成后应用。')});
window.addEventListener('beforeunload',event=>{if(!project||exited||project.setupPending)return;if(draftDirty){event.preventDefault();event.returnValue='';}if(draftDirty&&stages[selected].enabled){const body=JSON.stringify({id:project.id,key:key(),revision:draftRevision,text:$('prompt').value});navigator.sendBeacon('/api/draft',new Blob([body],{type:'application/json'}));}navigator.sendBeacon('/api/edit',new Blob([JSON.stringify({id:project.id,index:selected,workspace:$('projectPath').value,manual:$('manual').value,outputs:$('outputs').value,notes:$('notes').value,...extraRecords()})],{type:'application/json'}))});
async function leaveWorkflow(stopServer){
 if(exiting||exited)return;
 exiting=true;$('exitWorkflow').disabled=true;$('stopSoftware').disabled=true;document.querySelector('main').inert=true;
 $('saveState').textContent='正在保存并退出…';clearTimeout(draftTimer);
 try{
  while(operations.size)await Promise.all([...operations]);
  await records();
  if(project&&!project.setupPending){const t=JSON.parse($('templates').value);if(JSON.stringify(t)!==JSON.stringify(project.templates)){project=await api('templates',{id:project.id,templates:t});}}
  if(stopServer){
   await api('shutdown');exited=true;draftDirty=false;
   document.querySelector('main').hidden=true;$('exitPanel').hidden=false;
   $('exitWorkflow').hidden=true;$('stopSoftware').textContent='软件已关闭';$('saveState').textContent='已保存并关闭软件';
  }else{
   await list();
   project=null;selected=0;draftDirty=false;pendingDraft=Promise.resolve();localStorage.removeItem('lastMcmProject');
   $('work').hidden=true;$('exitWorkflow').hidden=true;$('stopSoftware').hidden=false;
   $('create').reset();$('createPanel').open=true;$('projects').value='';$('prompt').value='';


   document.querySelector('main').inert=false;$('exitWorkflow').disabled=false;$('stopSoftware').disabled=false;exiting=false;
   $('saveState').textContent='项目已保存，可新建或恢复项目';
   $('startFeedback').textContent='已退出当前项目。可创建新项目，或选择旧项目后点击“启动工作流”。';
   notify('已退出当前工作流。可以立即创建新项目，或从恢复项目列表选择旧项目。');
   window.scrollTo(0,0);$('name').focus();
  }
 }catch(e){document.querySelector('main').inert=false;$('exitWorkflow').disabled=false;$('stopSoftware').disabled=false;exiting=false;$('saveState').textContent='未退出：请先处理保存问题';notify('退出未完成，当前页面仍保留：'+e.message);}
}
$('exitWorkflow').onclick=()=>leaveWorkflow(false);
$('stopSoftware').onclick=()=>leaveWorkflow(true);
safe(async()=>{if(localStorage.getItem('workflowMode')!=='agent-reading-v1'){localStorage.removeItem('lastMcmProject');localStorage.setItem('workflowMode','agent-reading-v1');}stages=await api('config');await list();const id=localStorage.getItem('lastMcmProject');if(id){try{project=await api('get',{id});selected=project.current;$('kind').value=preferredKind();await render()}catch(e){notify('上次项目无法恢复，请从列表选择。')}}})();

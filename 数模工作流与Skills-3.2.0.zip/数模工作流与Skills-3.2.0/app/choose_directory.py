"""Native folder picker in a dedicated GUI process (no browser path guessing)."""
import json
import sys
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.title('赛题项目保存位置')
root.geometry('480x120')
tk.Label(root, text='请在文件夹窗口中选择保存位置。\n取消选择不会删除已导入材料。', padx=20, pady=20).pack()
root.attributes('-topmost', True)
root.update()
try:
    selected = filedialog.askdirectory(parent=root, title=('选择材料来源文件夹（只读扫描，保存位置将在启动时另选）' if 'source' in sys.argv else '选择本次赛题项目的保存位置（将在其中新建独立项目文件夹）'), mustexist=True)
    print(json.dumps({'directory': selected}, ensure_ascii=True), flush=True)
finally:
    root.destroy()

"""Start a persistent local service, wait until ready, then open its page."""
from pathlib import Path
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
URL = 'http://127.0.0.1:8765/'

def ready():
    try:
        with urllib.request.urlopen(URL, timeout=1) as response:
            return '数学建模 · 工作流引导' in response.read().decode('utf-8')
    except (OSError, UnicodeError):
        return False

def main():
    process = None
    if not ready():
        flags = (subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP) if sys.platform == 'win32' else 0
        with (ROOT / 'server-output.log').open('ab') as output, (ROOT / 'server-error.log').open('ab') as errors:
            process = subprocess.Popen([sys.executable, str(ROOT / 'server.py')], cwd=ROOT,
                stdin=subprocess.DEVNULL, stdout=output, stderr=errors,
                creationflags=flags, start_new_session=sys.platform != 'win32')
        for _ in range(40):
            if ready():
                break
            if process.poll() is not None:
                raise RuntimeError('服务启动失败，请查看 app/server-error.log（可能端口已被其他程序占用）')
            time.sleep(.25)
        else:
            raise RuntimeError('服务尚未就绪，请查看 app/server-error.log')
    print('本地工作流已就绪：' + URL)
    if '--no-open' not in sys.argv:
        webbrowser.open(URL)

if __name__ == '__main__':
    main()
